export type TUserLogin = {
  email: string;
  password: string;
};
